<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Redirect;

class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
    	$my_product_info=DB::table('products')
    	->get();
        // dd($deshboard_info);
    	if ($my_product_info!=null) {
    		$total = 0;
    		$due = 0;
    		foreach ($my_product_info as $value) {
    			$total += $value->product_price;
    			if ($value->product_status == "Unpaid") {
    				$due += $value->paid_amount;
    			}
    		}
    		return view ('home', [ 'my_product' => $my_product_info, 'total_price' => $total, 'total_due' => $due]);
    	}else{
    		return "Please import the database file then re-run";
    	}
    }

    public function paidAmount(Request $request)
    {
    	$paid_amount = $request->paid_amount;
    	$my_product_info=DB::table('products')
    	->get();
        // dd($deshboard_info);
    	if ($my_product_info!=null) {

    		foreach ($my_product_info as $value) {
    			if ($paid_amount > 0) {
    				if ($value->paid_amount > 0) {
    					if ($paid_amount >= $value->paid_amount) {
    						$data= array();
    						$data['paid_amount']=0;
    						$data['product_status']="Paid";
    						DB::table('products')
    						->where('product_id', $value->product_id)
    						->update($data);

    						$paid_amount-=$value->paid_amount;
    						// dd($paid_amount);
    					}else{
    						$partial_paid = $value->paid_amount - $paid_amount;
    						// dd($partial_paid);
    						$data= array();
    						$data['paid_amount']=$partial_paid;
    						DB::table('products')
    						->where('product_id', $value->product_id)
    						->update($data);

    						$paid_amount=0;
    					}
    				}
    			}


    		}
    		return Redirect::to('/home');
    	}else{
    		return "Please import the database file then re-run";
    	}
    }



    public function resetFunction()
    {
    	$my_product_info=DB::table('products')
    	->get();
        // dd($deshboard_info);
    	if ($my_product_info!=null) {
    		foreach ($my_product_info as $value) {
    			$paidAmount = $value->product_price;
    			$data= array();
				$data['paid_amount']=$paidAmount;
				$data['product_status']="Unpaid";
				DB::table('products')
				->where('product_id', $value->product_id)
				->update($data);
    		}
    		return Redirect::to('/home');
    	}else{
    		return "Please import the database file then re-run";
    	}
    }
}
