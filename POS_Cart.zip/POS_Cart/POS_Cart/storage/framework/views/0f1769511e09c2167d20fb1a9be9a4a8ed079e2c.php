<?php $__env->startSection('content'); ?>

<div class="container after_nav">
    <div class="row">
        <div class="col-sm-8">
            <table id="table_id" class="table table-striped table-dark">
               <thead>
                <tr>
                 <th>id</th>
                 <th>Name</th>
                 <th>Price</th>
                 <th>Due</th>
                 <th>Status</th>
             </tr>
         </thead>
         <tbody>
            <?php $__currentLoopData = $my_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_product_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo e($v_product_info -> product_id); ?></td>
                <td><?php echo e($v_product_info -> product_name); ?></td>
                <td><?php echo e($v_product_info -> product_price); ?></td>
                <td><?php echo e($v_product_info -> paid_amount); ?></td>
                <td><?php echo e($v_product_info -> product_status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="col-sm-4">
    <table class="table table-striped">
       <thead>
        <tr><th>Total</th><td> <?php echo e($total_price); ?></td><td> tk</td></tr>
        <tr><th>Due</th><td> <?php echo e($total_due); ?></td><td> tk</td></tr>
        <tr>
         <th>
            <form class="well form-horizontal" action="<?php echo e(route('home.paid')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <fieldset>
                    <input id="paid_amount" type="number" step="any" name="paid_amount" autofocus required>

                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Pay')); ?>

                    </button>

                </fieldset>
            </form>
        </th>
    </tr>
    <tr>
        <th>
            <a href="<?php echo e(route('home.reset')); ?>" type="button" class="btn btn-success" role="button"><b>Reset</b></a>
        </th>
    </tr>
</thead>
</table>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Install\xampp\htdocs\POS_Cart\resources\views/home.blade.php ENDPATH**/ ?>