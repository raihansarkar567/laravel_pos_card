<?php $__env->startSection('content'); ?>
<div class="gohome">
    <p>Step 1: Create new Database named by "pos_db", and Import the Database file to your xampp Localhost pos_db. DB file has given to the email attachment</p>
    <p>Step 2: Click Get Start button.</p>
    <a href="<?php echo e(route('home')); ?>" type="button" class="btn btn-info" role="button"><b>Get Start</b></a>
</div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\Emadiaid\New folder\POS_Cart\POS_Cart\resources\views/welcome.blade.php ENDPATH**/ ?>