@extends('layout.app')

@section('content')
<div class="gohome">
    <p>Step 1: Create new Database named by "pos_db", and Import the Database file to your xampp Localhost pos_db. DB file has given to the email attachment</p>
    <p>Step 2: Click Get Start button.</p>
    <a href="{{ route('home') }}" type="button" class="btn btn-info" role="button"><b>Get Start</b></a>
</div>


@endsection



