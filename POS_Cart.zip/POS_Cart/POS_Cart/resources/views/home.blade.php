@extends('layout.app')

@section('content')

<div class="container after_nav">
    <div class="row">
        <div class="col-sm-8">
            <table id="table_id" class="table table-striped table-dark">
               <thead>
                <tr>
                 <th>id</th>
                 <th>Name</th>
                 <th>Price</th>
                 <th>Due</th>
                 <th>Status</th>
             </tr>
         </thead>
         <tbody>
            @foreach($my_product as $v_product_info)
            <tr>

                <td>{{$v_product_info -> product_id}}</td>
                <td>{{$v_product_info -> product_name}}</td>
                <td>{{$v_product_info -> product_price}}</td>
                <td>{{$v_product_info -> paid_amount}}</td>
                <td>{{$v_product_info -> product_status}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="col-sm-4">
    <table class="table table-striped">
       <thead>
        <tr><th>Total</th><td> {{$total_price}}</td><td> tk</td></tr>
        <tr><th>Due</th><td> {{$total_due}}</td><td> tk</td></tr>
        <tr>
         <th>
            <form class="well form-horizontal" action="{{route('home.paid')}}" method="post">
                {{csrf_field()}}
                <fieldset>
                    <input id="paid_amount" type="number" step="any" name="paid_amount" autofocus required>

                    <button type="submit" class="btn btn-primary">
                        {{ __('Pay') }}
                    </button>

                </fieldset>
            </form>
        </th>
    </tr>
    <tr>
        <th>
            <a href="{{ route('home.reset') }}" type="button" class="btn btn-success" role="button"><b>Reset</b></a>
        </th>
    </tr>
</thead>
</table>
</div>
</div>
</div>

@endsection



